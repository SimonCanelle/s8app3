
close all;
clear all;
clc;

% Note : la concat�nation de vecteurs du genre vec = [vec nouvelle_valeur];
% est exponentiellement complexe... � �viter si le temps de calcul est une
% contrainte.

% Remplacer par des appels � fonctions : production du mod�le statistique,
% encodage, d�codage

%% Charger l'image � compresser

fichier_src='source1.jpg';

image_src=imread(fichier_src);

disp(['Image source : ', fichier_src]);

imshow(image_src);
title('Image source');

[L,C,nb_canaux]=size(image_src);

nb_pixels=L*C;

disp(['Nombre de pixels : ', num2str(nb_pixels)]);

image_vec=reshape(image_src,[numel(image_src), 1]);

%% Produire le mod�le statistique

% Identifier les symboles pr�sents

nb_symboles=length(image_vec);
symboles=unique(image_vec)';

disp(['Nombre de symboles : ', num2str(length(symboles))]);

% Compter le nombre d'occurrences

occurences=zeros(1,length(symboles));

for i=1:length(symboles)
   occurences(i)=length(find(image_vec==symboles(i)));
end

figure;
plot(symboles,occurences);
title('Nb d''occurrences par symbole');

% Calculer la distribution cumulative non-normalis�e : cumulatif(end) =
% length(image_vec). Pourrait �tre quantifi�e pour �tre transmise plus
% efficacement en m�tadonn�es

cumulatif=cumsum(occurences);
cumulatif=[0 cumulatif];

% Choix de la longueur des mots en bits

m=ceil(log2(cumulatif(end)))+2;

val_un    = 2^m;
val_demi  = val_un/2;
val_quart = val_demi/2;

%% Compression de l'image

disp(['1. Compression de l''image...']);

lk = 0;
uk = val_un;

% Calcul de la s�quence de scalings

disp(['   1.1. Calcul de la s�quence de scalings']);

scalings=[];

for k = 1:nb_symboles
    
    % Symbole � encoder
    
    symb   = image_vec(k);
    symb_k = find(symboles==symb);
    
    % Mise � jour des limites haute et basse (uk d'abord car n�cessite lk)

    range = uk - lk;
    uk = lk + floor(range*(cumulatif(symb_k+1)/cumulatif(end)));
    lk = lk + floor(range*(cumulatif(symb_k)/cumulatif(end)));
    
    % Mise � l'�chelle des bornes lk et uk
    
    scaling=1; % Indique qu'il faut continuer � chercher des scalings
    
    while (scaling==1)
        scaling=0;
        if uk<=val_demi
            % Scaling E1
            lk = 2*lk;
            uk = 2*uk;
            scalings=[scalings 1];
            scaling=1;
        elseif lk>=val_demi
            % Scaling E2
            lk = 2*(lk-val_demi);
            uk = 2*(uk-val_demi);
            scalings=[scalings 2];
            scaling=1;
        elseif (lk>=val_quart) && (uk<=val_demi+val_quart)
            % Scaling E3
            lk = 2*(lk-val_quart);
            uk = 2*(uk-val_quart);
            scalings=[scalings 3];
            scaling=1;
        end
    end
end

% Conversion de la suite de scalings en un train binaire

disp(['   1.2. Conversion en un train binaire']);

bits=[];
n3=0;

for n=1:length(scalings)
    if scalings(n)==1
        bits = [bits dec2bin(0,1)]; % E1 -> 0
        if (n3~=0)
            bits = [bits dec2bin(2^n3-1,n3)]; % Suivi de n3 fois 1
            n3=0;
        end
    elseif scalings(n)==2
        bits = [bits dec2bin(1,1)]; % E2 -> 1
        if (n3~=0)
            bits = [bits dec2bin(0,n3)]; % Suivi de n3 fois 0
            n3=0;
        end
    elseif scalings(n)==3
        n3=n3+1; % Compte le nombre n3 de scalings E3 cons�cutifs
    end
end

% Finalisation de la tag. Apr�s toutes les op�rations de scaling, 0.5 =
% 100... en binaire appartient toujours � l'intervalle. On ajoute m bits
% pour le premier symbole et n3 pour le dernier. Pourrait �tre optimis�.

bits = [bits dec2bin(1)];
for i=2:m+n3;
    bits = [bits dec2bin(0)];
end

disp(['D�bit donn�es : ', num2str(length(bits)/length(image_vec)), ' bits par symbole']);
disp(['D�bit m�tadonn�es : � calculer']);

%% D�compression de l'image

disp(['2. D�compression de l''image...']);

lk = 0;
uk = val_un;

image_vec_dec=[];

% Tag initiale

tag=0;
for nscale=1:m
    tag = 2*tag + double(bin2dec(bits(nscale)));
end

% D�codage symbole par symbole avec d�calage de la tag binaire � chaque
% scaling

for k = 1:(nb_symboles-1) % On pourrait aussi s'arr�ter lorsque toute la tag a �t� d�cod�e

    range = uk - lk;
    
    % Identification du symbole
    
    % Je n'utilise pas le principe de la tag mise � l'�chelle (t*) de
    % Sayood pour ne pas avoir de diff�rence de pr�cision de calcul entre
    % les bornes lk et uk et la tag
    
    for j=1:length(symboles)
        a = lk + floor(range*(cumulatif(j)/cumulatif(end)));
        b = lk + floor(range*(cumulatif(j+1)/cumulatif(end)));
        if tag>=a && tag<b
            lk = a;
            uk = b;
            symb_k = j;
            break
        end
    end
    
    image_vec_dec=[image_vec_dec; symboles(symb_k)];

    % V�rification de la validit� du d�codage (impossible dans la r�alit�)
    
    if image_vec_dec(k)~=image_vec(k)
        disp(['Erreur de d�codage symbole num. ' int2str(k)]);
        return;
    end
    
    % Mise � l'�chelle des bornes lk et uk
    
    scaling=1; % Indique qu'il faut continuer � chercher des scalings
    
    while (scaling==1)
        scaling=0;
        if uk<=val_demi
            % Scaling E1
            lk = 2*lk;
            uk = 2*uk;
            nscale=nscale+1;
            tag = 2*tag;
            tag = tag + bin2dec(bits(nscale)); % Ajoute le bit de poids faible
            scaling=1;
        elseif lk>=val_demi
            % Scaling E2
            lk = 2*(lk-val_demi);
            uk = 2*(uk-val_demi);
            nscale=nscale+1;
            tag = 2*(tag-val_demi);
            tag = tag + bin2dec(bits(nscale)); % Ajoute le bit de poids faible
            scaling=1;
        elseif (lk>=val_quart) && (uk<=val_demi+val_quart)
            % Scaling E3
            lk = 2*(lk-val_quart);
            uk = 2*(uk-val_quart);
            nscale=nscale+1;
            tag = 2*(tag-val_quart);
            tag = tag + bin2dec(bits(nscale)); % Ajoute le bit de poids faible
            scaling=1;
        end
    end
end

% D�codage du dernier symbole sans scalings et d�calage de la tag (le train
% binaire est en principe vide, ou presque vide)

range = uk - lk;

% Identification du dernier symbole

for j=1:length(symboles)
    a = lk + floor(range*(cumulatif(j)/cumulatif(end)));
    b = lk + floor(range*(cumulatif(j+1)/cumulatif(end)));
    if tag>=a && tag<b
        symb_k = j;
        break
    end
end

image_vec_dec=[image_vec_dec; symboles(symb_k)];

% V�rification de la validit� du d�codage (impossible dans la r�alit�)

if image_vec_dec(end)~=image_vec(end)
    disp(['Erreur de d�codage symbole num. ' int2str(nb_symboles)]);
    return;
end

disp('Encodage et d�codage r�ussi');

%% Reconstruction de l'image

image_dec=reshape(image_vec_dec,[L,C,nb_canaux]);

figure;
imshow(image_dec);
title('Image reconstruite');