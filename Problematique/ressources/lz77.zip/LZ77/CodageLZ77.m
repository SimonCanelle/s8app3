%% Modifi� par khaled.lakhdhar@usherbrooke.ca 12-03-2011

 
clear all
close all
clc

% *************************************************************************
% INITIALISATION
% *************************************************************************
% INITIALISATION DES VARIABLES ET DES MATRICES GLOBALS
NomFichierCompresse = 'CodageLZ77.bin'; % Fichier du texte compress?
DimBuffer = 0; % A changer
DimF_Analyse = 0; % A changer
Buffer = zeros(1,DimBuffer);

% EXTRACTION DES PARAMETRES
Texte = textread('TexteACompresse.txt','%s','delimiter','\n','whitespace','');
Texte = double(cell2mat(Texte'));

% Ajout de quelques z?ros ? la fin du texte pour que la derni?re fen?tre
% fonctionne
Restant = ceil(length(Texte)/DimF_Analyse)*DimF_Analyse - length(Texte);
Texte = [Texte zeros(1,DimF_Analyse)];

% *************************************************************************
% COMPRESSEUR LZ77
% *************************************************************************

% VOTRE CODE DE COMPRESSION











% Enregistrement du vecteur codee dans un fichier
fid1 = fopen(NomFichierCompresse,'w');
fwrite(fid1,TexteCodee,'uint8');
fclose(fid1);
% *************************************************************************
% DECOMPRESSEUR LZ77

% *************************************************************************
% Initialisation de la matrice contenant le texte d?cod?
TexteDecodee = zeros(1,10*length(TexteCodee)); % Texte Codee est le vecteur code

% Initialisation du pointeur ? la position initiale
Pointeur1 = DimBuffer + 1;

% Balayage des codes LZ77
for i = 1:3:length(TexteCodee)
    Code = TexteCodee(1,i:i+2);
    if Code(1,2) == 0
        % Le code contient qu'un seul caract?re ? coder
        TexteDecodee(1,Pointeur1) = Code(1,3);
        Pointeur1 = Pointeur1 +1;
    else
        Buffer = TexteDecodee(1,Pointeur1-DimBuffer : Pointeur1-1);
        Pointeur = DimBuffer - Code(1,1) + 1;
        TexteDecodee(1,Pointeur1:Pointeur1+Code(1,2)) = ...
            [Buffer(1,Pointeur:Pointeur+Code(1,2)-1)  Code(1,3)];
        Pointeur1 = Pointeur1 + Code(1,2) + 1;
    end
end
TexteDecodee = TexteDecodee(1,DimBuffer+1:end);
TexteDecodee = char(TexteDecodee);
fid = fopen('TexteDecompresse.txt','w');
fwrite(fid,TexteDecodee, 'uchar');
fclose(fid);